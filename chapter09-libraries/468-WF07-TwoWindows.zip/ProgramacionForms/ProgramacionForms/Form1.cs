﻿//Abraham García

using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ProgramacionForms
{
    public partial class Form1 : Form
    {
        anyadirLibro formLibro;
        string[] datos;
        List<Libro> libros;

        public Form1()
        {
            InitializeComponent();
            datos = File.ReadAllLines("libros.txt");
            libros = new List<Libro>();
            int propiedad = 0;
            string autor = "", titulo = "", ubicacion = "";
            for (int i = 0; i < datos.Length; i++)
            {
                if (propiedad == 0) autor = datos[i];
                else if (propiedad == 1) titulo = datos[i];
                else if (propiedad == 2) ubicacion = datos[i];
                propiedad++;
                if (propiedad == 3)
                {
                    libros.Add(new Libro(autor, titulo, ubicacion));
                    propiedad = 0;
                }
            }

            foreach (Libro libro in libros)
                lbPrincipal.Items.Add(libro);

            formLibro = new anyadirLibro();
            
        }
        
        private void btnAnyadir_Click(object sender, EventArgs e)
        {
            formLibro.SetLibro(libros.Count + 1);
            formLibro.ShowDialog();
            Libro l = new Libro(formLibro.GetAutor(), formLibro.GetTitulo(),
                formLibro.GetUbicacion());
            if (!formLibro.GetCancelado())
            {
                if (formLibro.GetBoton())
                {
                    libros.Add(l);
                    lbPrincipal.Items.Add(l);
                    StreamWriter output = File.CreateText("libros.txt");
                    foreach (Libro libro in libros)
                    {
                        output.WriteLine(libro.Autor);
                        output.WriteLine(libro.Titulo);
                        output.WriteLine(libro.Ubicacion);
                    }
                    output.Close();
                    lblEstado.Text = "Guardado";
                }
                else 
                    lblEstado.Text = "Cancelado";
            }
            else
                lblEstado.Text = "Error";
        }
    }
}