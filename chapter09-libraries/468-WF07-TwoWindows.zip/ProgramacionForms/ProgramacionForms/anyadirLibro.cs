﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ProgramacionForms
{
    public partial class anyadirLibro : Form
    {
 
        public anyadirLibro()
        {
            InitializeComponent();
        }

        bool boton;

        public string GetAutor() { return tbAutor.Text; }
        public string GetTitulo() { return tbTitulo.Text; }
        public string GetUbicacion() { return tbUbicacion.Text; }
        public bool GetBoton() { return boton; }
        public bool GetCancelado()
        {
            if (tbAutor.Text.Trim() == "" ||
                tbTitulo.Text.Trim() == "" ||
                tbUbicacion.Text.Trim() == "")
                return true;
            return false;
        }
        public void SetLibro(int n) 
        { 
            lblAnyadiendo.Text = "Añadiendo el libro " + n; 
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            boton = true;
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            boton = false;
            Close();
        }
    }
}
