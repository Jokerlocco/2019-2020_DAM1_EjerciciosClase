﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramacionForms
{
    class Libro
    {
        public string Autor { get; set; }
        public string Titulo { get; set; }
        public string Ubicacion { get; set; }

        public Libro(string autor, string titulo, string ubicacion)
        {
            Autor = autor;
            Titulo = titulo;
            Ubicacion = ubicacion;
        }

        public override string ToString()
        {
            return Titulo + ", de " + Autor + " (en " + Ubicacion + ").";
        }
    }
}
