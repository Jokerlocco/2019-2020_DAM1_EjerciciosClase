﻿namespace ProgramacionForms
{
    partial class anyadirLibro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAceptar = new System.Windows.Forms.Button();
            this.lblAutor = new System.Windows.Forms.Label();
            this.lbltitulo = new System.Windows.Forms.Label();
            this.lblUbicacion = new System.Windows.Forms.Label();
            this.tbAutor = new System.Windows.Forms.TextBox();
            this.tbTitulo = new System.Windows.Forms.TextBox();
            this.tbUbicacion = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.lblAnyadiendo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAceptar
            // 
            this.btnAceptar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAceptar.Location = new System.Drawing.Point(79, 174);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(82, 36);
            this.btnAceptar.TabIndex = 0;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lblAutor.Location = new System.Drawing.Point(26, 54);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(42, 17);
            this.lblAutor.TabIndex = 2;
            this.lblAutor.Text = "Autor";
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbltitulo.Location = new System.Drawing.Point(26, 88);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(43, 17);
            this.lbltitulo.TabIndex = 2;
            this.lbltitulo.Text = "Titulo";
            // 
            // lblUbicacion
            // 
            this.lblUbicacion.AutoSize = true;
            this.lblUbicacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lblUbicacion.Location = new System.Drawing.Point(26, 122);
            this.lblUbicacion.Name = "lblUbicacion";
            this.lblUbicacion.Size = new System.Drawing.Size(70, 17);
            this.lblUbicacion.TabIndex = 2;
            this.lblUbicacion.Text = "Ubicacion";
            // 
            // tbAutor
            // 
            this.tbAutor.Location = new System.Drawing.Point(114, 54);
            this.tbAutor.Name = "tbAutor";
            this.tbAutor.Size = new System.Drawing.Size(240, 20);
            this.tbAutor.TabIndex = 3;
            // 
            // tbTitulo
            // 
            this.tbTitulo.Location = new System.Drawing.Point(114, 88);
            this.tbTitulo.Name = "tbTitulo";
            this.tbTitulo.Size = new System.Drawing.Size(240, 20);
            this.tbTitulo.TabIndex = 3;
            // 
            // tbUbicacion
            // 
            this.tbUbicacion.Location = new System.Drawing.Point(114, 119);
            this.tbUbicacion.Name = "tbUbicacion";
            this.tbUbicacion.Size = new System.Drawing.Size(240, 20);
            this.tbUbicacion.TabIndex = 3;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.Location = new System.Drawing.Point(237, 174);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(87, 36);
            this.btnCancelar.TabIndex = 0;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // lblAnyadiendo
            // 
            this.lblAnyadiendo.AutoSize = true;
            this.lblAnyadiendo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblAnyadiendo.Location = new System.Drawing.Point(123, 9);
            this.lblAnyadiendo.Name = "lblAnyadiendo";
            this.lblAnyadiendo.Size = new System.Drawing.Size(155, 20);
            this.lblAnyadiendo.TabIndex = 4;
            this.lblAnyadiendo.Text = "Añadiendo el libro x";
            // 
            // anyadirLibro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(381, 233);
            this.Controls.Add(this.lblAnyadiendo);
            this.Controls.Add(this.tbUbicacion);
            this.Controls.Add(this.tbTitulo);
            this.Controls.Add(this.tbAutor);
            this.Controls.Add(this.lblUbicacion);
            this.Controls.Add(this.lbltitulo);
            this.Controls.Add(this.lblAutor);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Name = "anyadirLibro";
            this.Text = "anyadirLibro";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Label lblUbicacion;
        private System.Windows.Forms.TextBox tbAutor;
        private System.Windows.Forms.TextBox tbTitulo;
        private System.Windows.Forms.TextBox tbUbicacion;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Label lblAnyadiendo;
    }
}