﻿using System;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp08
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Se borrará el archivo, está seguro de salir sin guardar??",
                    "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if ( res == DialogResult.Yes)
                listDatos.Items.Clear();
        }

        private void exportarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult resp = MessageBox.Show("Desea Guardar el archivo?", "Aviso",
                                     MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (resp == DialogResult.Yes)
            {
                string path =
                    Microsoft.VisualBasic.Interaction.InputBox
                    ("Introduce el nombre del fichero");

                StreamWriter fichero;
                if (File.Exists(path))
                {
                    fichero = File.AppendText(path);
                }
                else
                {
                    fichero = File.CreateText(path);
                }
                for (int i = 0; i < listDatos.Items.Count; i++)
                {
                    fichero.WriteLine(listDatos.Items[i]);
                }
                fichero.Close();
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult conf = MessageBox.Show("Se borrará el archivo, está seguro de salir sin guardar??",
                    "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (conf == DialogResult.Yes)
                this.Close();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Autor: Cristina Francés Romo \n Versión: 8");
        }

        private void btnAnyadir_Click(object sender, EventArgs e)
        {
            if (txtAnyadir.Text == "")
                MessageBox.Show("Debe instroducir alguna palabra");
            else
                listDatos.Items.Add(txtAnyadir.Text);
            txtAnyadir.Text = "";
        }
    }
}
