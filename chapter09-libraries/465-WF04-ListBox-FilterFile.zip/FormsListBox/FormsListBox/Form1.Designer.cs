﻿namespace FormsListBox
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTextos = new System.Windows.Forms.ListBox();
            this.btCargar = new System.Windows.Forms.Button();
            this.tbRuta = new System.Windows.Forms.TextBox();
            this.btAumentar = new System.Windows.Forms.Button();
            this.btDisminuir = new System.Windows.Forms.Button();
            this.tbTextoFiltrar = new System.Windows.Forms.TextBox();
            this.btFiltrar = new System.Windows.Forms.Button();
            this.lbNombre = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbTextos
            // 
            this.lbTextos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTextos.FormattingEnabled = true;
            this.lbTextos.Location = new System.Drawing.Point(12, 12);
            this.lbTextos.Name = "lbTextos";
            this.lbTextos.Size = new System.Drawing.Size(238, 251);
            this.lbTextos.TabIndex = 0;
            // 
            // btCargar
            // 
            this.btCargar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btCargar.Location = new System.Drawing.Point(170, 308);
            this.btCargar.Name = "btCargar";
            this.btCargar.Size = new System.Drawing.Size(80, 20);
            this.btCargar.TabIndex = 1;
            this.btCargar.Text = "Cargar";
            this.btCargar.UseVisualStyleBackColor = true;
            this.btCargar.Click += new System.EventHandler(this.btCargar_Click);
            // 
            // tbRuta
            // 
            this.tbRuta.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRuta.Location = new System.Drawing.Point(12, 308);
            this.tbRuta.Name = "tbRuta";
            this.tbRuta.Size = new System.Drawing.Size(152, 20);
            this.tbRuta.TabIndex = 2;
            // 
            // btAumentar
            // 
            this.btAumentar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btAumentar.Location = new System.Drawing.Point(12, 334);
            this.btAumentar.Name = "btAumentar";
            this.btAumentar.Size = new System.Drawing.Size(239, 23);
            this.btAumentar.TabIndex = 3;
            this.btAumentar.Text = "+";
            this.btAumentar.UseVisualStyleBackColor = true;
            this.btAumentar.Click += new System.EventHandler(this.btAumentar_Click);
            // 
            // btDisminuir
            // 
            this.btDisminuir.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btDisminuir.Location = new System.Drawing.Point(11, 363);
            this.btDisminuir.Name = "btDisminuir";
            this.btDisminuir.Size = new System.Drawing.Size(239, 23);
            this.btDisminuir.TabIndex = 4;
            this.btDisminuir.Text = "-";
            this.btDisminuir.UseVisualStyleBackColor = true;
            this.btDisminuir.Click += new System.EventHandler(this.btDisminuir_Click);
            // 
            // tbTextoFiltrar
            // 
            this.tbTextoFiltrar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTextoFiltrar.Location = new System.Drawing.Point(12, 395);
            this.tbTextoFiltrar.Name = "tbTextoFiltrar";
            this.tbTextoFiltrar.Size = new System.Drawing.Size(152, 20);
            this.tbTextoFiltrar.TabIndex = 5;
            // 
            // btFiltrar
            // 
            this.btFiltrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btFiltrar.Location = new System.Drawing.Point(170, 395);
            this.btFiltrar.Name = "btFiltrar";
            this.btFiltrar.Size = new System.Drawing.Size(80, 20);
            this.btFiltrar.TabIndex = 6;
            this.btFiltrar.Text = "Filtrar";
            this.btFiltrar.UseVisualStyleBackColor = true;
            this.btFiltrar.Click += new System.EventHandler(this.btFiltrar_Click);
            // 
            // lbNombre
            // 
            this.lbNombre.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbNombre.AutoSize = true;
            this.lbNombre.Location = new System.Drawing.Point(67, 281);
            this.lbNombre.Name = "lbNombre";
            this.lbNombre.Size = new System.Drawing.Size(120, 13);
            this.lbNombre.TabIndex = 8;
            this.lbNombre.Text = "Hecho por Pablo Vigara";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 436);
            this.Controls.Add(this.lbNombre);
            this.Controls.Add(this.btFiltrar);
            this.Controls.Add(this.tbTextoFiltrar);
            this.Controls.Add(this.btDisminuir);
            this.Controls.Add(this.btAumentar);
            this.Controls.Add(this.tbRuta);
            this.Controls.Add(this.btCargar);
            this.Controls.Add(this.lbTextos);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbTextos;
        private System.Windows.Forms.Button btCargar;
        private System.Windows.Forms.TextBox tbRuta;
        private System.Windows.Forms.Button btAumentar;
        private System.Windows.Forms.Button btDisminuir;
        private System.Windows.Forms.TextBox tbTextoFiltrar;
        private System.Windows.Forms.Button btFiltrar;
        private System.Windows.Forms.Label lbNombre;
    }
}

