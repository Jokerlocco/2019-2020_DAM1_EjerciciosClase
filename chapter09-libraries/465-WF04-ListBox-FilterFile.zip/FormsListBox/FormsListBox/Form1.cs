﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

// Pablo Vigara Fernandez

namespace FormsListBox
{
    public partial class Form1 : Form
    {
        private string[] input;

        public Form1()
        {
            InitializeComponent();
        }

        private void btCargar_Click(object sender, EventArgs e)
        {
            string path = tbRuta.Text;
            if (!File.Exists(path))
                MessageBox.Show("Fichero no encontrado");
            else
            {
                try
                {
                    input = File.ReadAllLines(path);
                }
                catch (Exception)
                {
                    MessageBox.Show("Error leyendo el fichero");
                }

                for (int i = 0; i < input.Length; i++)
                {
                    lbTextos.Items.Add(input[i]);
                }
            }
        }

        private void btFiltrar_Click(object sender, EventArgs e)
        {
            string texto = tbTextoFiltrar.Text;

            if (texto.Length == 0)
                MessageBox.Show("Insertar al menos un caracter para buscar");
            else
            {
                lbTextos.Items.Clear();
                for (int i = 0; i < input.Length; i++)
                {
                    if (input[i].Contains(texto))
                        lbTextos.Items.Add(input[i]);
                }
            } 
        }

        private void btAumentar_Click(object sender, EventArgs e)
        {
            float tamanyoNuevo = lbTextos.Font.Size + 1f;
            lbTextos.Font = new Font(lbTextos.Font.FontFamily, tamanyoNuevo);
        }

        private void btDisminuir_Click(object sender, EventArgs e)
        {
            float tamanyoNuevo = lbTextos.Font.Size - 1f;
            lbTextos.Font = new Font(lbTextos.Font.FontFamily, tamanyoNuevo);
        }
    }
}
