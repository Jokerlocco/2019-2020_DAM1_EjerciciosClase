﻿using System;
using System.IO;
using System.Windows.Forms;

// Pablo Vigara Fernandez

namespace Dialogos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btCargarFichero_Click(object sender, EventArgs e)
        {
            DialogResult fichero = dialogoCargarFichero.ShowDialog();
            string[] input = Array.Empty<string>();

            if (fichero != DialogResult.Cancel)
            {
                input = File.ReadAllLines(dialogoCargarFichero.FileName);
            }

            for (int i = 0; i < input.Length ; i++)
            {
                lbTexto.Items.Add(input[i]);
            }
        }

        private void btCambiarLetra_Click(object sender, EventArgs e)
        {
            DialogResult fuente = dialogoFuente.ShowDialog();

            if (fuente != DialogResult.Cancel)
                lbTexto.Font = dialogoFuente.Font;
        }

        private void btCambiarColor_Click(object sender, EventArgs e)
        {
            DialogResult color = dialogoColor.ShowDialog();

            if (color != DialogResult.Cancel)
                lbTexto.ForeColor = dialogoColor.Color;
        }

        private void btGuardarFichero_Click(object sender, EventArgs e)
        {
            DialogResult guardar = dialogoGuardar.ShowDialog();

            if (guardar != DialogResult.Cancel)
            {
                StreamWriter output;
                try
                {
                    output = new StreamWriter(
                    File.Create(dialogoGuardar.FileName));
                    for (int i = 0; i < lbTexto.Items.Count; i++)
                    {
                        output.WriteLine(lbTexto.Items[i]);
                    }
                    output.Close();
                }
                catch (Exception)
                {
                    MessageBox.Show("Error guardando los datos", 
                        "Error", MessageBoxButtons.OK,
                         MessageBoxIcon.Error);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
