﻿namespace Dialogos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dialogoColor = new System.Windows.Forms.ColorDialog();
            this.dialogoCargarFichero = new System.Windows.Forms.OpenFileDialog();
            this.dialogoGuardar = new System.Windows.Forms.SaveFileDialog();
            this.dialogoFuente = new System.Windows.Forms.FontDialog();
            this.lbTexto = new System.Windows.Forms.ListBox();
            this.btCargarFichero = new System.Windows.Forms.Button();
            this.btCambiarLetra = new System.Windows.Forms.Button();
            this.btCambiarColor = new System.Windows.Forms.Button();
            this.btGuardarFichero = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dialogoCargarFichero
            // 
            this.dialogoCargarFichero.FileName = "openFileDialog1";
            // 
            // lbTexto
            // 
            this.lbTexto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTexto.FormattingEnabled = true;
            this.lbTexto.Location = new System.Drawing.Point(12, 12);
            this.lbTexto.Name = "lbTexto";
            this.lbTexto.Size = new System.Drawing.Size(321, 277);
            this.lbTexto.TabIndex = 0;
            // 
            // btCargarFichero
            // 
            this.btCargarFichero.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btCargarFichero.Location = new System.Drawing.Point(12, 312);
            this.btCargarFichero.Name = "btCargarFichero";
            this.btCargarFichero.Size = new System.Drawing.Size(321, 23);
            this.btCargarFichero.TabIndex = 1;
            this.btCargarFichero.Text = "Cargar fichero";
            this.btCargarFichero.UseVisualStyleBackColor = true;
            this.btCargarFichero.Click += new System.EventHandler(this.btCargarFichero_Click);
            // 
            // btCambiarLetra
            // 
            this.btCambiarLetra.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btCambiarLetra.Location = new System.Drawing.Point(12, 341);
            this.btCambiarLetra.Name = "btCambiarLetra";
            this.btCambiarLetra.Size = new System.Drawing.Size(321, 23);
            this.btCambiarLetra.TabIndex = 2;
            this.btCambiarLetra.Text = "Cambiar fuente";
            this.btCambiarLetra.UseVisualStyleBackColor = true;
            this.btCambiarLetra.Click += new System.EventHandler(this.btCambiarLetra_Click);
            // 
            // btCambiarColor
            // 
            this.btCambiarColor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btCambiarColor.Location = new System.Drawing.Point(12, 370);
            this.btCambiarColor.Name = "btCambiarColor";
            this.btCambiarColor.Size = new System.Drawing.Size(321, 23);
            this.btCambiarColor.TabIndex = 3;
            this.btCambiarColor.Text = "Cambiar color";
            this.btCambiarColor.UseVisualStyleBackColor = true;
            this.btCambiarColor.Click += new System.EventHandler(this.btCambiarColor_Click);
            // 
            // btGuardarFichero
            // 
            this.btGuardarFichero.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btGuardarFichero.Location = new System.Drawing.Point(12, 399);
            this.btGuardarFichero.Name = "btGuardarFichero";
            this.btGuardarFichero.Size = new System.Drawing.Size(321, 23);
            this.btGuardarFichero.TabIndex = 4;
            this.btGuardarFichero.Text = "Guardar fichero";
            this.btGuardarFichero.UseVisualStyleBackColor = true;
            this.btGuardarFichero.Click += new System.EventHandler(this.btGuardarFichero_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 441);
            this.Controls.Add(this.btGuardarFichero);
            this.Controls.Add(this.btCambiarColor);
            this.Controls.Add(this.btCambiarLetra);
            this.Controls.Add(this.btCargarFichero);
            this.Controls.Add(this.lbTexto);
            this.Name = "Form1";
            this.Text = "Pablo Vigara Fernandez";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog dialogoColor;
        private System.Windows.Forms.OpenFileDialog dialogoCargarFichero;
        private System.Windows.Forms.SaveFileDialog dialogoGuardar;
        private System.Windows.Forms.FontDialog dialogoFuente;
        private System.Windows.Forms.ListBox lbTexto;
        private System.Windows.Forms.Button btCargarFichero;
        private System.Windows.Forms.Button btCambiarLetra;
        private System.Windows.Forms.Button btCambiarColor;
        private System.Windows.Forms.Button btGuardarFichero;
    }
}

