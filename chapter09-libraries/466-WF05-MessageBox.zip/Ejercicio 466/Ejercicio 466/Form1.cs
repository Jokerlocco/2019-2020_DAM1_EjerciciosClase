﻿//KIKO
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Ejercicio_466
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            FormClosing += Form1_FormClosing;
        }

        private void BtnCargar_Click(object sender, EventArgs e)
        {
            if (inputRuta.Text != "" && File.Exists(inputRuta.Text))
            {
                try
                {
                    lbTexto.Items.AddRange(File.ReadAllLines(inputRuta.Text));
                }
                catch (PathTooLongException)
                {
                    Console.WriteLine("ERROR: Path too long");
                }
                catch (IOException)
                {
                    Console.WriteLine("ERROR: IO Exception");
                }
                catch (Exception i)
                {
                    Console.WriteLine("ERROR: " + i);
                }
            }
            else
                MessageBox.Show("Debe introducir una ruta válida.",
                    "Error",
                    MessageBoxButtons.OK,MessageBoxIcon.Warning) ;            
        }

        private void BtnFiltrar_Click(object sender, EventArgs e)
        {
            string filtro = inputFiltro.Text;
            DialogResult respuesta = DialogResult.Yes;

            if (filtro == "")
            {
                    respuesta =
                    MessageBox.Show("Desea mostrar todas las cadenas?",
                    "Alto!",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            }

            if (respuesta == DialogResult.Yes)
                for (int n = lbTexto.Items.Count - 1; n >= 0; n--)
                {
                    if (!lbTexto.Items[n].ToString().ToUpper().
                        Contains(filtro.ToUpper()))
                    {
                        lbTexto.Items.RemoveAt(n);
                    }
                }

            else
                lbTexto.Items.Clear();
        }

        private void BtnMas_Click(object sender, EventArgs e)
        {
            lbTexto.Font =
                new Font(lbTexto.Font.FontFamily, lbTexto.Font.Size + 2);
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            lbTexto.Font = 
                new Font(lbTexto.Font.FontFamily, lbTexto.Font.Size - 2);
        }

        
       private void Form1_FormClosing(object sender, FormClosingEventArgs e)
       {
            var x = MessageBox.Show("Desea exportar el texto filtrado? \n" +
                                     "Los datos se perderan. ",
                                     "Cerrar programa", 
                                     MessageBoxButtons.YesNo, 
                                     MessageBoxIcon.Question);

            if (x == DialogResult.Yes)
            {
                string nuevaRuta =
                    Microsoft.VisualBasic.Interaction.InputBox
                    ("Introduce el nombre del nuevo fichero",
                    "Exportar archivo",
                    "ejemplo.txt");

                StreamWriter sw = new StreamWriter(nuevaRuta);

                for (int n = lbTexto.Items.Count - 1; n >= 0; n--)
                {
                    sw.WriteLine(lbTexto.Items[n].ToString());
                }

                sw.Close();
                MessageBox.Show("Texto guardado con exito.",
                   "Hasta la proxima!",
                   MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }         
        }

    }
}
