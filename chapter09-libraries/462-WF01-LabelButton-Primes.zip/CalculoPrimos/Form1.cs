﻿//Jose Valera 1ºDAM

using System;
using System.IO;
using System.Windows.Forms;

namespace CalculoPrimos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int cantidad = 0;
            StreamWriter archivo;

            try
            {
                archivo = new StreamWriter("primos.txt");
                for (int i = 2; i <= 1000; i++)
                {
                    int j = 2;
                    bool esPrimo = true;

                    while (esPrimo && j < i)
                    {
                        if (i % j == 0)
                            esPrimo = false;

                        j++;
                    }

                    if (esPrimo)
                    {
                        if(cantidad != 0)
                            archivo.Write(" ");

                        archivo.Write(i);
                        cantidad++;
                    }
                }
                archivo.WriteLine();
                archivo.Close();
            }
            catch(IOException e1)
            {
                Console.WriteLine("Error: " + e1.Message);
            }

            lblResultado.Text = "Primos encontrados: " + cantidad;
        }
    }
}
