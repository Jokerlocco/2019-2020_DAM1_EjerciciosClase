﻿//Lautaro Álvaro Fernández

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _470windowsForms9
{
    public partial class Form1 : Form
    {
        List<Libro> libros = new List<Libro>(new Libro[]{
            new Libro { Autor = "uno", Titulo = "uno", Editorial = "uno" },
            new Libro { Autor = "dos", Titulo = "dos", Editorial = "dos" },
            new Libro { Autor = "tres", Titulo = "tres", Editorial = "tres" }});

        public Form1()
        {
            InitializeComponent();
            dataGridView1.DataSource = libros;
        }

        public class Libro
        {
            public string Autor { get; set; }
            public string Titulo { get; set; }
            public string Editorial { get; set; }
        }
    }
}
