﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace ProgramacionForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnAnalizar_Click(object sender, EventArgs e)
        {
            int cantidadEspacios = 0;
            int cantidadNOEspacios = 0;

            StreamReader input = File.OpenText(tbArchivo.Text);
            string linea;
            do
            {
                linea = input.ReadLine();
                if (linea != null)
                {
                    for (int i = 0; i < linea.Length; i++)
                    {
                        if (linea[i] == ' ')
                            cantidadEspacios++;
                        else
                            cantidadNOEspacios++;
                    }
                }
            } while (linea != null);
            input.Close();

            lblCaracteres.Text = "Espacios en blanco: " + cantidadEspacios +
                " / Otros caracteres: " + cantidadNOEspacios;
        }
    }
}
