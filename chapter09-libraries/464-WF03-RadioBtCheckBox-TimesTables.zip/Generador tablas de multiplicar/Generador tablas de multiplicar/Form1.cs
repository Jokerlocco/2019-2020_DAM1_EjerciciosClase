﻿//Kiko
using System;
using System.IO;
using System.Windows.Forms;

namespace Generador_tablas_de_multiplicar
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void BtnGenerar_Click(object sender, EventArgs e)
        {
            int n1=1;
            int n2=10;
            try
            {
                n1 = Convert.ToInt32(tb1.Text);
                n2 = Convert.ToInt32(tb2.Text);
            }
            catch (Exception )
            {
                MessageBox.Show("Solo numeros");
            }
            int inicio;
            if (check0.Checked)
                inicio = 0;
            else
                inicio = 1;

            if(rbFichero.Checked)
            {
                try
                {
                    StreamWriter fichero = new StreamWriter("tablas.txt");                   

                    for (int i = n1; i <= n2; i++)
                    {
                        for(int j = inicio; j <= 10;j++)
                        {
                            fichero.WriteLine(i + " x " + j + " = " + i * j);
                        }
                        fichero.WriteLine();
                    }

                    fichero.Close();
                    MessageBox.Show("Completado.");
                }
                catch (PathTooLongException)
                {
                    Console.WriteLine("ERROR: Path too long");
                }
                catch (IOException)
                {
                    Console.WriteLine("ERROR: IO Exception");
                }
                catch (Exception i)
                {
                    Console.WriteLine("ERROR: " + i);
                }
            }

            else
            {
                string tablas = "";
                for (int i = n1; i <= n2; i++)
                {
                    for (int j = inicio; j <= 10; j++)
                    {
                       tablas+=(i + " x " + j + " = " + i * j +"\n");
                    }
                    tablas += "\n";
                }
                MessageBox.Show(tablas);
            }
        }

       
    }
}
