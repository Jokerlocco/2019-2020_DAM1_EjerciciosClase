﻿using System;

class Game
{
    public Game()
    {
        Console.WriteLine("Starting game...");
    }
}
