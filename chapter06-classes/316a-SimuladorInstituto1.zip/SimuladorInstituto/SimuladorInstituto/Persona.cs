﻿abstract class Persona
{
    public string Nombre { get; set; }
    public byte Edad { get; set; }
    public string LugarActual { get; set; }

    protected byte dia;
    protected byte hora;
    protected byte minuto;
    

    public Persona(string nombre, byte edad)
    {
        Nombre = nombre;
        Edad = edad;
        dia = 0;
        hora = 0;
        minuto = 0;
        LugarActual = "Casa";
    }

    public virtual void Animar15Minutos()
    {
        Simulador.AvanzarReloj(ref dia, ref hora, ref minuto);
    }

    public void MostrarEstado()
    {
        System.Console.WriteLine(Nombre + ": " + LugarActual);
    }
}
