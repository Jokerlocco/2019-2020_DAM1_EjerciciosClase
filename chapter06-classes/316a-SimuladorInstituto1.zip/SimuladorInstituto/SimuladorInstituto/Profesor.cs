﻿class Profesor : Persona
{
    int turno;

    public Profesor(string nombre, byte edad)
        : base(nombre, edad)
    {
        turno = new System.Random().Next(2);
    }

    public override void Animar15Minutos()
    {

        base.Animar15Minutos();
        if (turno == 0)
        {
            if ((hora < 8) || (hora > 15))
                LugarActual = "Casa";
            else if ((hora == 8) || (hora == 15))
                LugarActual = "Coche";
            else
                LugarActual = "Clase";
        } 
        else
        {
            if ((hora < 15) || (hora > 21))
                LugarActual = "Casa";
            else if ((hora == 21) || (hora == 15))
                LugarActual = "Coche";
            else
                LugarActual = "Clase";
        }
    }
}
