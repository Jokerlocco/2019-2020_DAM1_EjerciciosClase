﻿class Conserje : Persona
{
    public Conserje(string nombre, byte edad)
        : base(nombre, edad)
    {
        
    }

    public override void Animar15Minutos()
    {
        base.Animar15Minutos();
        if ((hora < 8) || (hora > 15))
            LugarActual = "Casa";
        else if ((hora == 8) || (hora == 15))
            LugarActual = "Autobús";
        else
            LugarActual = "Conserjería";
    }

}
