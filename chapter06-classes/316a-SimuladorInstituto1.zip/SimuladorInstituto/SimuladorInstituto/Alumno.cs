﻿class Alumno : Persona
{
    public int Aula { get; set; }
    protected int horaDespertar;
    protected int horaAcostar;
    protected int horaEntrarAClase;
    protected int horaSalirDeClase;



    public Alumno(string nombre, byte edad, int aula)
        : base(nombre, edad)
    {
        Aula = aula;
        System.Random generador = new System.Random();
        if (generador.Next(2) == 0)
        {
            horaEntrarAClase = 15;
            horaSalirDeClase = 21;
            horaAcostar = 23;
            horaDespertar = 9 + generador.Next(3);
        }
        else
        {
            horaEntrarAClase = 8;
            horaSalirDeClase = 13;
            horaAcostar = 21 + generador.Next(2);
            horaDespertar = 7;
        }
    }

    public override void Animar15Minutos()
    {
        base.Animar15Minutos();
        if ((hora == horaEntrarAClase-1) || (hora == horaSalirDeClase))
            LugarActual = "Camino a clase";
        else if ((hora < horaEntrarAClase) || (hora > horaSalirDeClase))
            LugarActual = "Casa";
        else
            LugarActual = "Clase";
    }
}
