﻿using System;

class Simulador
{
    
    static void Main(string[] args)
    {
        Persona[] personas = new Persona[5];
        personas[0] = new Alumno("Jose", 20, 202);
        personas[1] = new Alumno("Araceli", 21, 202);
        personas[2] = new Profesor("Nacho", 22);
        personas[3] = new Profesor("Yolanda", 23);
        personas[4] = new Conserje("Juan", 24);

        Aula a1 = new Aula(202, "1 DAM");
        Aula a2 = new Aula(203, "1 DAW");

        string[] nombresDias = { "Lunes" , "Martes", "Miércoles",
            "Jueves", "Viernes", "Sábado", "Domingo" };

        byte dia = 0;
        byte hora = 0;
        byte minuto = 0;

        string accion;
        do
        {
            Console.WriteLine(nombresDias[dia] + " " +
                hora.ToString("00") +":" +
                minuto.ToString("00") + "h");
            foreach (Persona p in personas)
                p.MostrarEstado();
            a1.MostrarAlumnos(personas);
            a2.MostrarAlumnos(personas);

            Console.WriteLine();
            Console.Write("Pulsa Intro para seguir o escribe FIN para terminar... ");
            accion = Console.ReadLine();
            if (accion.ToUpper() != "FIN")
                foreach (Persona p in personas)
                    p.Animar15Minutos();
            
            AvanzarReloj(ref dia, ref hora, ref minuto);
        }
        while (accion.ToUpper() != "FIN");
    }


    public static void AvanzarReloj(ref byte dia, ref byte hora, ref byte minuto)
    {
        minuto += 15;
        if (minuto >= 60)
        {
            minuto = 0;
            hora++;
            if (hora >= 24)
            {
                hora = 0;
                dia++;
                if (dia >= 7)
                {
                    dia = 0;
                }
            }
        }
    }
}
