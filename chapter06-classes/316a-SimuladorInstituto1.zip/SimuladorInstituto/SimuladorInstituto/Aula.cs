﻿using System;

class Aula
{
    public int Codigo { get; set; }
    public string Nombre { get; set; }
    public Aula(int codigo, string nombre)
    {
        Codigo = codigo;
        Nombre = nombre;
    }

    public void MostrarAlumnos(Persona[] gente)
    {
        string respuesta = "";
        foreach(Persona p in gente)
        {
            if (p is Alumno)
            {
                if ((p.LugarActual == "Clase") 
                        && (((Alumno)p).Aula == Codigo))
                    respuesta += p.Nombre + " ";
            }
        }
        Console.Write(Nombre+ ": ");
        if (respuesta == "")
            Console.WriteLine("(nadie)");
        else
            Console.WriteLine(respuesta);
    }
}
