﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblio2020
{
    class Program
    {
        static void Main(string[] args)
        {
            GestorDeLibros gestor = new GestorDeLibros();
            gestor.Ejecutar();
        }
    }
}
