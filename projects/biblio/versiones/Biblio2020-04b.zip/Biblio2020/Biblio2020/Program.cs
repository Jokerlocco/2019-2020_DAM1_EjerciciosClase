﻿namespace Biblio2020
{
    class Program
    {
        static void Main(string[] args)
        {
            GestorDeLibros gestor = new GestorDeLibros();
            gestor.Ejecutar();
        }
    }
}
