﻿class EnemyLevel4
{
}
