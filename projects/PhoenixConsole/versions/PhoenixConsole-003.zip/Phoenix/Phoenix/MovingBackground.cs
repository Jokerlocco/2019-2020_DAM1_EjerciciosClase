﻿class MovingBackground
{
}
