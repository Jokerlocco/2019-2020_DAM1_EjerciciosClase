﻿class Stage
{
}

