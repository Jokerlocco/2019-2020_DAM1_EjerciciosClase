﻿class Shield
{
}
