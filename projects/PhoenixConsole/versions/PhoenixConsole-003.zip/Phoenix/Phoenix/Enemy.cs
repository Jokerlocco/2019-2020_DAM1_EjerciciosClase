﻿class Enemy : Sprite
{
    public void Move()
    {

    }
}
