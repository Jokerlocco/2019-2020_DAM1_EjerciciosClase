﻿// PlayerShot
// Part of ConsolePhoenix

// Version    Date     By + Changes
// -------  --------  ------------------------------------
//  0.04     09-01-20  Nacho: Empty skeleton + constructor

class PlayerShot : Shot
{
    public PlayerShot(int x, int y)
        : base(x, y, -1)
    {
        // TO DO
    }
}