﻿// Enemy
// Part of ConsolePhoenix

// Version    Date     By + Changes
// -------  --------  ------------------------------------
//  0.04     09-01-20  Nacho: Move changed to Update, virtual
//  0.01     08-01-20  Nacho: Empty skeleton

class Enemy : Sprite
{
}
