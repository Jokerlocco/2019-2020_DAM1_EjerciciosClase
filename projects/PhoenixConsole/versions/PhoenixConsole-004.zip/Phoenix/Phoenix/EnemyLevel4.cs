﻿// EnemyLevel4
// Part of ConsolePhoenix

// Version    Date     By + Changes
// -------  --------  ------------------------------------
//  0.04     09-01-20  Nacho: Added inheritance
//  0.01     08-01-20  Nacho: Empty skeleton

class EnemyLevel4 : Enemy
{
}
