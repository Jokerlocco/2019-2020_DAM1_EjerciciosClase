﻿// EnemyShot
// Part of ConsolePhoenix

// Version    Date     By + Changes
// -------  --------  ------------------------------------
//  0.04     09-01-20  Nacho: Empty skeleton + constructor

class EnemyShot : Shot
{
    public EnemyShot(int x, int y)
        : base(x, y, 1)
    {
        // TO DO
    }
}