﻿// Scoreboard
// Part of ConsolePhoenix

// Version    Date     By + Changes
// -------  --------  ------------------------------------
//  0.04     09-01-20  Nacho: Empty Reset, AddPoints, LiveLost, Draw
//  0.01     08-01-20  Nacho: Empty skeleton

class Scoreboard
{
    private int points = 0;

    public void Reset()
    {
        // TO DO
    }

    public void AddPoints(int points)
    {
        // TO DO
    }

    public void LiveLost()
    {
        // TO DO
    }

    public void Draw()
    {

    }
}
