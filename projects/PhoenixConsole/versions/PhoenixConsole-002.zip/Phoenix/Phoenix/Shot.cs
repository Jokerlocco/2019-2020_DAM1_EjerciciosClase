﻿class Shot
{
}

