﻿using System;

class HelpScreen
{
    public void Run()
    {
        Console.WriteLine("Help");
        Console.WriteLine();
        Console.WriteLine("Move left and right");
        Console.WriteLine("ESC to quit");
        Console.ReadLine();
    }
}