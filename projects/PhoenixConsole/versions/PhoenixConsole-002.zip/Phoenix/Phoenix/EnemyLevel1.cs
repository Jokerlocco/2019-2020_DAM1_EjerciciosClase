﻿class EnemyLevel1 : Enemy
{
}
