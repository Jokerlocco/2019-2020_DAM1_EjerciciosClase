﻿class Scoreboard
{
}
