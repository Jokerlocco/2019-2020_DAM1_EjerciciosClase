﻿using System;

class DemoScreen
{
    public void Run()
    {
        Console.WriteLine("Demo");
        Console.WriteLine();
        Console.WriteLine("Check back soon...");
        Console.ReadLine();
    }
}
