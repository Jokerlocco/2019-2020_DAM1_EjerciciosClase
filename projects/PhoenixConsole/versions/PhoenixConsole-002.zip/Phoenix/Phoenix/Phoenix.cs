﻿class Phoenix
{
    static void Main()
    {
        WelcomeScreen ws = new WelcomeScreen();
        ws.Run();
    }
}
