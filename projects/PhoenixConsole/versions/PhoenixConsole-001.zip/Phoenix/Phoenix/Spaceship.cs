﻿class Spaceship
{
}

