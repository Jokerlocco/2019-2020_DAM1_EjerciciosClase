﻿class Phoenix
{
    static void Main()
    {
    }
}
