﻿class Sprite
{
    protected int x;
    protected int y;
}
