﻿class EnemyLevel2
{
}
