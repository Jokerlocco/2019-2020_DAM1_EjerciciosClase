﻿namespace ColeccMP3
{
    partial class FormEditar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbCategoria = new System.Windows.Forms.TextBox();
            this.lbCategoria = new System.Windows.Forms.Label();
            this.tbFichero = new System.Windows.Forms.TextBox();
            this.lbFichero = new System.Windows.Forms.Label();
            this.tbTitulo = new System.Windows.Forms.TextBox();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.tbArtista = new System.Windows.Forms.TextBox();
            this.lbArtista = new System.Windows.Forms.Label();
            this.tbFecha = new System.Windows.Forms.TextBox();
            this.lbFecha = new System.Windows.Forms.Label();
            this.tbTamanyoKB = new System.Windows.Forms.TextBox();
            this.lbTamanyoKB = new System.Windows.Forms.Label();
            this.tbUbicacion = new System.Windows.Forms.TextBox();
            this.lbUbicacion = new System.Windows.Forms.Label();
            this.btCancelar = new System.Windows.Forms.Button();
            this.btAceptar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbCategoria
            // 
            this.tbCategoria.Location = new System.Drawing.Point(133, 119);
            this.tbCategoria.Margin = new System.Windows.Forms.Padding(4);
            this.tbCategoria.Name = "tbCategoria";
            this.tbCategoria.Size = new System.Drawing.Size(289, 22);
            this.tbCategoria.TabIndex = 15;
            // 
            // lbCategoria
            // 
            this.lbCategoria.AutoSize = true;
            this.lbCategoria.Location = new System.Drawing.Point(33, 119);
            this.lbCategoria.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCategoria.Name = "lbCategoria";
            this.lbCategoria.Size = new System.Drawing.Size(69, 17);
            this.lbCategoria.TabIndex = 14;
            this.lbCategoria.Text = "Categoría";
            // 
            // tbFichero
            // 
            this.tbFichero.Location = new System.Drawing.Point(133, 87);
            this.tbFichero.Margin = new System.Windows.Forms.Padding(4);
            this.tbFichero.Name = "tbFichero";
            this.tbFichero.Size = new System.Drawing.Size(289, 22);
            this.tbFichero.TabIndex = 13;
            // 
            // lbFichero
            // 
            this.lbFichero.AutoSize = true;
            this.lbFichero.Location = new System.Drawing.Point(33, 87);
            this.lbFichero.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbFichero.Name = "lbFichero";
            this.lbFichero.Size = new System.Drawing.Size(55, 17);
            this.lbFichero.TabIndex = 12;
            this.lbFichero.Text = "Fichero";
            // 
            // tbTitulo
            // 
            this.tbTitulo.Location = new System.Drawing.Point(133, 55);
            this.tbTitulo.Margin = new System.Windows.Forms.Padding(4);
            this.tbTitulo.Name = "tbTitulo";
            this.tbTitulo.Size = new System.Drawing.Size(289, 22);
            this.tbTitulo.TabIndex = 11;
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Location = new System.Drawing.Point(33, 55);
            this.lbTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(43, 17);
            this.lbTitulo.TabIndex = 10;
            this.lbTitulo.Text = "Titulo";
            // 
            // tbArtista
            // 
            this.tbArtista.Location = new System.Drawing.Point(133, 23);
            this.tbArtista.Margin = new System.Windows.Forms.Padding(4);
            this.tbArtista.Name = "tbArtista";
            this.tbArtista.Size = new System.Drawing.Size(289, 22);
            this.tbArtista.TabIndex = 9;
            // 
            // lbArtista
            // 
            this.lbArtista.AutoSize = true;
            this.lbArtista.Location = new System.Drawing.Point(33, 23);
            this.lbArtista.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbArtista.Name = "lbArtista";
            this.lbArtista.Size = new System.Drawing.Size(48, 17);
            this.lbArtista.TabIndex = 8;
            this.lbArtista.Text = "Artista";
            // 
            // tbFecha
            // 
            this.tbFecha.Location = new System.Drawing.Point(133, 213);
            this.tbFecha.Margin = new System.Windows.Forms.Padding(4);
            this.tbFecha.Name = "tbFecha";
            this.tbFecha.Size = new System.Drawing.Size(289, 22);
            this.tbFecha.TabIndex = 21;
            // 
            // lbFecha
            // 
            this.lbFecha.AutoSize = true;
            this.lbFecha.Location = new System.Drawing.Point(33, 213);
            this.lbFecha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbFecha.Name = "lbFecha";
            this.lbFecha.Size = new System.Drawing.Size(47, 17);
            this.lbFecha.TabIndex = 20;
            this.lbFecha.Text = "Fecha";
            // 
            // tbTamanyoKB
            // 
            this.tbTamanyoKB.Location = new System.Drawing.Point(133, 181);
            this.tbTamanyoKB.Margin = new System.Windows.Forms.Padding(4);
            this.tbTamanyoKB.Name = "tbTamanyoKB";
            this.tbTamanyoKB.Size = new System.Drawing.Size(289, 22);
            this.tbTamanyoKB.TabIndex = 19;
            // 
            // lbTamanyoKB
            // 
            this.lbTamanyoKB.AutoSize = true;
            this.lbTamanyoKB.Location = new System.Drawing.Point(33, 181);
            this.lbTamanyoKB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbTamanyoKB.Name = "lbTamanyoKB";
            this.lbTamanyoKB.Size = new System.Drawing.Size(92, 17);
            this.lbTamanyoKB.TabIndex = 18;
            this.lbTamanyoKB.Text = "Tamaño (KB)";
            // 
            // tbUbicacion
            // 
            this.tbUbicacion.Location = new System.Drawing.Point(133, 149);
            this.tbUbicacion.Margin = new System.Windows.Forms.Padding(4);
            this.tbUbicacion.Name = "tbUbicacion";
            this.tbUbicacion.Size = new System.Drawing.Size(289, 22);
            this.tbUbicacion.TabIndex = 17;
            // 
            // lbUbicacion
            // 
            this.lbUbicacion.AutoSize = true;
            this.lbUbicacion.Location = new System.Drawing.Point(33, 149);
            this.lbUbicacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbUbicacion.Name = "lbUbicacion";
            this.lbUbicacion.Size = new System.Drawing.Size(70, 17);
            this.lbUbicacion.TabIndex = 16;
            this.lbUbicacion.Text = "Ubicación";
            // 
            // btCancelar
            // 
            this.btCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancelar.Location = new System.Drawing.Point(322, 253);
            this.btCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(100, 28);
            this.btCancelar.TabIndex = 23;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            // 
            // btAceptar
            // 
            this.btAceptar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btAceptar.Location = new System.Drawing.Point(204, 254);
            this.btAceptar.Margin = new System.Windows.Forms.Padding(4);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(100, 28);
            this.btAceptar.TabIndex = 22;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // FormEditar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 303);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.tbFecha);
            this.Controls.Add(this.lbFecha);
            this.Controls.Add(this.tbTamanyoKB);
            this.Controls.Add(this.lbTamanyoKB);
            this.Controls.Add(this.tbUbicacion);
            this.Controls.Add(this.lbUbicacion);
            this.Controls.Add(this.tbCategoria);
            this.Controls.Add(this.lbCategoria);
            this.Controls.Add(this.tbFichero);
            this.Controls.Add(this.lbFichero);
            this.Controls.Add(this.tbTitulo);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.tbArtista);
            this.Controls.Add(this.lbArtista);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormEditar";
            this.Text = "Editar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbCategoria;
        private System.Windows.Forms.Label lbCategoria;
        private System.Windows.Forms.TextBox tbFichero;
        private System.Windows.Forms.Label lbFichero;
        private System.Windows.Forms.TextBox tbTitulo;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.TextBox tbArtista;
        private System.Windows.Forms.Label lbArtista;
        private System.Windows.Forms.TextBox tbFecha;
        private System.Windows.Forms.Label lbFecha;
        private System.Windows.Forms.TextBox tbTamanyoKB;
        private System.Windows.Forms.Label lbTamanyoKB;
        private System.Windows.Forms.TextBox tbUbicacion;
        private System.Windows.Forms.Label lbUbicacion;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button btAceptar;
    }
}